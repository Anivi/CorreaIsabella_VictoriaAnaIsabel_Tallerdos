package CorreaIsabella_VictoriaAnaIsabel_Tallerdos;

import java.util.LinkedList;

import processing.core.PApplet;
import processing.core.PVector;

public class Modificadores {
	private PApplet app;
	private PVector pos;
	private int punto;
	private int estado;
	
	public Modificadores(PApplet app) {
		
	}
	
	public void pintar() {
		
	}
	
	
	
}
