package CorreaIsabella_VictoriaAnaIsabel_Tallerdos;

import processing.core.PApplet;
import processing.core.PVector;

public class Elementos {
	private PApplet app;
	private PVector pos;
	private int punto;
	
	public Elementos(PApplet app) {
		
		
		
	}
	public void pintar() {
		
	}
	
}
