package CorreaIsabella_VictoriaAnaIsabel_Tallerdos;

import java.util.*;

import processing.core.*;

public class Automators extends Thread{

	private PApplet app;
	private PVector pos;
	private PVector vel;
	private int puntaje;
	private int direccion;
	
	public Automators(PApplet app) {
			
	}
	public void pintar() {
		
	}
	public void run() {
		
	}
	public void validar() {
		
	}
}
